let dinheiro = 100;
let estoqueSementes = {
  "Milho": 3,
  "Tomate": 2,
  "Alface": 1
};
let ferramentas = 0;
let fertilizantes = 0;
let campo = [];
let terrenoInicial = 5;
let emCidade = false;
let telaLoja = null;
let diaAtual = 1;
let sementeSelecionada = "Milho";
let clima = "Sol";
let mostrarDialogoVendedor = false;
let mostrarMercadorias = false;
let imgMilho, imgTomate, imgAlface, imgVendedor;

let sementesDisponiveis = [
  { nome: "Milho", preco: 10, diasParaCrescer: 5, precoVenda: 30 },
  { nome: "Tomate", preco: 15, diasParaCrescer: 4, precoVenda: 40 },
  { nome: "Alface", preco: 8, diasParaCrescer: 3, precoVenda: 20 }
];

function preload() {
  imgMilho = loadImage('New Piskel (1).png');     // Milho atualizado
  imgTomate = loadImage('New Piskel (2).png');    // Tomate
  imgAlface = loadImage('New Piskel (3).png');    // Alface
  imgVendedor = loadImage('New Piskel-1.png.png'); // Vendedor
}

function setup() {
  createCanvas(800, 600);
  textAlign(LEFT, TOP);
  for (let i = 0; i < terrenoInicial; i++) {
    campo.push({ status: "vazio", tipo: null, crescimento: 0 });
  }
}

function draw() {
  background(emCidade ? '#a0d8ef' : 220);
  if (telaLoja) {
    desenharLoja(telaLoja);
  } else if (emCidade) {
    desenharCidade();
  } else {
    desenharFazenda();
  }
}

function desenharFazenda() {
  fill(0);
  textSize(16);
  textAlign(LEFT, TOP);
  text("Dinheiro: " + dinheiro, 20, 10);
  text("Dia: " + diaAtual + " | Clima: " + clima, 20, 30);

  for (let i = 0; i < campo.length; i++) {
    let x = 100 + (i % 5) * 110;
    let y = 100 + floor(i / 5) * 110;

    if (campo[i].status === "vazio") fill('#b0e57c');
    else if (campo[i].status === "plantado") fill('#a3c672');
    else if (campo[i].status === "pronto") fill('#f9d976');

    rect(x, y, 100, 100);
    if (campo[i].status === "plantado") {
      image(getImagemSemente(campo[i].tipo.nome), x + 25, y + 25, 50, 50);
    } else if (campo[i].status === "pronto") {
      fill(0);
      text("Colher", x + 25, y + 40);
    }
  }

  // Botões com imagens de sementes
  let imagens = [imgMilho, imgTomate, imgAlface];
  let nomes = Object.keys(estoqueSementes);

  for (let i = 0; i < nomes.length; i++) {
    fill(sementeSelecionada === nomes[i] ? '#add8e6' : 255);
    rect(10, 70 + i * 60, 100, 50, 10);
    image(imagens[i], 15, 75 + i * 60, 40, 40);
    fill(0);
    textAlign(LEFT, CENTER);
    text("(" + estoqueSementes[nomes[i]] + ")", 60, 90 + i * 60);
  }

  // Botão Ir para Cidade
  fill(0, 100, 255);
  rect(10, 550, 150, 40, 10);
  fill(255);
  textAlign(CENTER, CENTER);
  text("Ir para Cidade", 85, 570);

  // Botão Passar o Dia
  fill(255, 165, 0);
  rect(width - 160, 550, 150, 40, 10);
  fill(0);
  text("Passar o Dia", width - 85, 570);
}

function desenharCidade() {
  background('#a0d8ef');
  noStroke();
  fill('#7ec850');
  rect(0, height / 2, width, height / 2); // grama
  fill('#d3d3d3');
  rect(0, 500, width, 100); // calçada

  fill('#ffcc99');
  rect(150, 150, 100, 100);
  fill(0);
  textAlign(CENTER, CENTER);
  text("Loja de\nSementes", 200, 200);

  fill(0, 100, 255);
  rect(10, 550, 150, 40, 10);
  fill(255);
  text("Voltar à Fazenda", 85, 570);
}

function desenharLoja(tipo) {
  background(240);
  image(imgVendedor, 500, 180, 100, 100);

  fill('#8b4513');
  rect(450, 300, 300, 50);

  textSize(18);
  fill(0);
  textAlign(LEFT, TOP);

  if (!mostrarDialogoVendedor) {
    fill(255);
    rect(100, 100, 250, 50, 10);
    fill(0);
    text("Olá, como posso ajudar?", 110, 110);
  } else if (mostrarMercadorias) {
    text("Clique para comprar:", 100, 170);
    for (let i = 0; i < sementesDisponiveis.length; i++) {
      let s = sementesDisponiveis[i];
      fill('#f0e68c');
      rect(100, 200 + i * 60, 300, 50);
      fill(0);
      text(`${s.nome} - Preço: ${s.preco}`, 110, 215 + i * 60);
    }
  }

  fill(0, 100, 255);
  rect(10, 550, 150, 40, 10);
  fill(255);
  textAlign(CENTER, CENTER);
  text("Voltar", 85, 570);
}

function mousePressed() {
  if (telaLoja) {
    if (!mostrarDialogoVendedor) {
      if (mouseX > 100 && mouseX < 350 && mouseY > 100 && mouseY < 150) {
        mostrarDialogoVendedor = true;
        mostrarMercadorias = true;
        return;
      }
    } else if (mostrarMercadorias) {
      for (let i = 0; i < sementesDisponiveis.length; i++) {
        let y = 200 + i * 60;
        if (mouseX > 100 && mouseX < 400 && mouseY > y && mouseY < y + 50) {
          let s = sementesDisponiveis[i];
          if (dinheiro >= s.preco) {
            dinheiro -= s.preco;
            estoqueSementes[s.nome] = (estoqueSementes[s.nome] || 0) + 1;
          }
        }
      }
    }

    if (mouseX > 10 && mouseX < 160 && mouseY > 550 && mouseY < 590) {
      telaLoja = null;
      mostrarDialogoVendedor = false;
      mostrarMercadorias = false;
    }
    return;
  }

  if (emCidade) {
    if (mouseX > 150 && mouseX < 250 && mouseY > 150 && mouseY < 250) {
      telaLoja = "Sementes";
    }
    if (mouseX > 10 && mouseX < 160 && mouseY > 550 && mouseY < 590) {
      emCidade = false;
    }
  } else {
    for (let i = 0; i < campo.length; i++) {
      let x = 100 + (i % 5) * 110;
      let y = 100 + floor(i / 5) * 110;
      if (mouseX > x && mouseX < x + 100 && mouseY > y && mouseY < y + 100) {
        if (campo[i].status === "vazio") {
          let semente = sementesDisponiveis.find(s => s.nome === sementeSelecionada);
          if (estoqueSementes[semente.nome] > 0) {
            campo[i] = { status: "plantado", tipo: semente, crescimento: 0 };
            estoqueSementes[semente.nome]--;
          }
        } else if (campo[i].status === "pronto") {
          dinheiro += campo[i].tipo.precoVenda;
          campo[i] = { status: "vazio", tipo: null, crescimento: 0 };
        }
      }
    }

    // Seleção de sementes com imagens
    let nomes = Object.keys(estoqueSementes);
    for (let i = 0; i < nomes.length; i++) {
      let yBase = 70 + i * 60;
      if (mouseX > 10 && mouseX < 110 && mouseY > yBase && mouseY < yBase + 50) {
        sementeSelecionada = nomes[i];
      }
    }

    if (mouseX > 10 && mouseX < 160 && mouseY > 550 && mouseY < 590) {
      emCidade = true;
    }

    if (mouseX > width - 160 && mouseX < width - 10 && mouseY > 550 && mouseY < 590) {
      avancarDia();
    }
  }
}

function avancarDia() {
  diaAtual++;
  clima = random() < 0.3 ? "Chuva" : "Sol";
  for (let planta of campo) {
    if (planta.status === "plantado") {
      planta.crescimento += clima === "Chuva" ? 2 : 1;
      if (planta.crescimento >= planta.tipo.diasParaCrescer) {
        planta.status = "pronto";
      }
    }
  }
}

function getImagemSemente(nome) {
  if (nome === "Milho") return imgMilho;
  if (nome === "Tomate") return imgTomate;
  if (nome === "Alface") return imgAlface;
  return null;
}
